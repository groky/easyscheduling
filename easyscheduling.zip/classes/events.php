<?php
function create_event($name, $organiser, $description, $multi){
  global $conn;
  
  $name = mysql_real_escape_string($name);
  $organiser = mysql_real_escape_string($organiser);
  $description = mysql_real_escape_string($description);
  
  $sql = "Insert into event (event_name, description, organisation_id, multi_day, contact_person)
          values ('$name', '$description', " . get_org_id() ." ,$multi , '$organiser'); ";

  $qh = mysql_query($sql, $conn);
  
  return mysql_insert_id($conn);
  
}

function update_event($name, $organiser, $description, $multi, $event_id){
  global $conn;

  $name = mysql_real_escape_string($name);
  $organiser = mysql_real_escape_string($organiser);
  $description = mysql_real_escape_string($description);
  
  $sql = "Update event set event_name='$name', description='$description', organisation_id=".
          get_org_id() . ", multi_day=$multi, contact_person='$organiser' where id=$event_id;";
  
  mysql_query($sql, $conn);
}

function get_events($org_id){
  global $conn;
  
  $sql = "Select * from event where organisation_id = $org_id";
  
  $qh = mysql_query($sql, $conn);
  
  $events = array();
  
  if($qh!=false){
    while ($line=mysql_fetch_assoc($qh)){
      $events[] = $line;
    }
  }
  
  //print("<pre>". var_dump($events) . "</pre>");
  return $events;
  
}

function get_event($id, $org_id){
  global $conn;
  
  $sql = "Select * from event where id=$id and organisation_id=$org_id";
  
  $qh = mysql_query($sql, $conn);
  $row = array();
  if($qh){
    $row = mysql_fetch_assoc($qh);
  }
  /*while($line=){
    $row = $line;
  }*/
  
  return $row;
  
}

function get_event_from_id($id){
  global $conn;
  
  $sql = "Select * from event where id=$id;";
  
  $qh = mysql_query($sql, $conn);
  $row = array();
  if($qh){
    $row = mysql_fetch_assoc($qh);
  }
  /*while($line=){
    $row = $line;
  }*/
  
  return $row;
}

function get_event_name($event_id, $org_id){
  $event = get_event($event_id, $org_id);
  return $event['event_name'];
}


function create_timetable($timetable, $event_id){
  global $conn;

  $sql_check = "Select * from event_option where event_id=$event_id;";
  $qh = mysql_query($sql_check, $conn);
  
  //if there are any items in the event_option table
  if(count(mysql_fetch_array($qh))>0){
    //remove the locations
    while($row = mysql_fetch_assoc($qh)){
      $delete_location = "delete from location where options_id=".$row['options_id'].";";
      mysql_query($delete_location, $conn);
    }
    //remove them options
    $delete = "delete from event_option where event_id=$event_id";
    mysql_query($delete);
  }

  foreach($timetable as $row){
  
    $sql = "insert into event_option (o_start, o_end, start_time, end_time, event_id) 
              values";
    $sql_loc = "insert into location (location, options_id) values";
  
    $start_date = strlen($row['start'])<1? "null" : strtotime($row['start']);
    $start_time = strlen($row['start_time'])<1 ? "null" : strtotime($row['start_time']);
    $end_time =   strlen($row['end_time'])<1 ? "null" : strtotime($row['end_time']);
    $end_date = strlen($row['end'])<1 ? "null" : strtotime($row['end']);
    $location = mysql_real_escape_string(strlen($row['location'])<1 ? "null" : $row['location']);
    if($start_date!="null"){
      $sql = $sql . " ($start_date, $end_date, $start_time, $end_time, $event_id);";
      //alert($sql);
      mysql_query($sql, $conn);
      
      if($location!="null"){
        $options_id = mysql_insert_id($conn);
        $sql_loc = $sql_loc . " ('$location', $options_id);";
        //alert($sql_loc);
        mysql_query($sql_loc, $conn);
      }
    }
  }
  
  mysql_query($sql, $conn);
}

function get_timetable($event_id){
  global $conn;
  
  //$date_format = "d-m-Y";
  $date_format = "D, d M Y";
  $time_format = "g:i A";
  
  $sql = "Select * from event_option where event_id=$event_id;";
  $qh = mysql_query($sql, $conn);
  
  $timetable = array();
  while($line = mysql_fetch_assoc($qh)){
    $temp = array();
    
    $temp['start'] = get_date($date_format, $line['o_start']);
    
    if(strlen($line['o_end'])>0){
      $temp['end'] = get_date($date_format, $line['o_end']);
    }
    else{
      $temp['end'] = "";
    }
    
    $temp['start_time'] = get_date($time_format, $line['start_time']);
    
    $temp['end_time'] = get_date($time_format,$line['end_time']);
    
    $temp['option_id'] = $line['id'];
       
    $locale = get_location($line['id']);
    if(count($locale)>0){
      $temp['location'] = $locale['location'];
    }
    else{
      $temp['location'] = null;
    }
    
    $timetable[] = $temp;
    
  }
  
  $count = count($timetable);
  if ($count<7){
    $diff = 7-$count;
    while($diff>0){
      $diff--;
      $temp = array();
      $temp['start'] = null;
      $temp['end'] = null;
      $temp['start_time'] = null;
      $temp['end_time'] = null;
      $temp['location'] = null;
      $timetable[] = $temp;
    }
  }
  
  //echo("<pre>".print_r($timetable)."</pre>");
  return $timetable;
}

function get_location($option_id){
  global $conn;
  $sql = "Select * from location where options_id=$option_id;";
  $qh = mysql_query($sql, $conn);
  return mysql_fetch_assoc($qh);
}

function event_has_ipx($event_id){
  global $conn;
  
  $exist = false;
  
  $sql = "Select * from link where event_id=$event_id";
  $qh = mysql_query($sql, $conn);
  
  while($line=mysql_fetch_assoc($qh)){
    if(!is_bool($line)){
      $exist = true;
    }
  }
  
  return $exist;
}


function get_member_email($event_id){
  global $conn;
  
  $sql = "select email from organisation, event
          where
          event.organisation_id = organisation.id and
          event.id = $event_id;";
          
  $qh = mysql_query($sql, $conn);
  
  $email = mysql_fetch_assoc($qh);
  
  return $email['email'];
}


function create_link($event_id, $link ,$ipx){
  global $conn;
  
  $sql = "Insert into link (event_id, link, reference) values ($event_id, '" . mysql_real_escape_string($link) . "','" . mysql_real_escape_string($ipx) . "');" ;
  
  //print($sql);
  
  mysql_query($sql, $conn);
}

function get_link($event_id){
  global $conn;
  
  $sql = "Select * from link where event_id=$event_id";
  $qh = mysql_query($sql, $conn);
  
  $link = mysql_fetch_assoc($qh);
  
  return $link;
}

function create_member_choice($member_id, $option_ids){
  global $conn;
  
  foreach($option_ids as $key=>$option_id ){
    $sql = "Insert into member_option (member_id, option_id) 
            values ($member_id, $option_id);";
    mysql_query($sql, $conn);
  }
  
}

function remove_old_choices($member_id){
  global $conn;
  
  $sql = "Delete from member_option where member_id=$member_id;";
  
  mysql_query($sql, $conn);
}

function event_has_poll_results($event_id){
  global $conn;
  
  $exists = false;
  
  $sql = "select member_id from member_link, link
          where
          member_link.reference = link.reference and
          link.event_id=$event_id;";
  $qh = mysql_query($sql, $conn);
  
  if($qh){
    while($row = mysql_fetch_array($qh)){
      if(!is_bool($row)){
        $exists = true;
      }
    }
  }
  return $exists;
}

function get_poll_result_list($event_id){
  global $conn;
  $sql = "select m.id, m.first_name, m.last_name, mo.option_id
from member m, member_option mo, link l, member_link ml
where
ml.reference = l.reference and
ml.member_id = mo.member_id and
m.id = mo.member_id and
l.event_id = $event_id;";
  
  $qh = mysql_query($sql, $conn);
  
  $results = array();
  $invitee = array();

  if($qh){
    while($row = mysql_fetch_assoc($qh)){
      $invitee['name'] = $row['first_name'] . " " . $row['last_name'];
      $invitee['id'] = $row['id'];
      $invitee['option_id'] = $row['option_id'];
      
      $results[] = $invitee;
    }   
  }
  
  $temp = array();
  $member_id = 0;
  $people = array();
  for($i=0;$i<count($results);$i++){
    $person = $results[$i];
    
    if($member_id!=$person['id']){
      $temp['name'] = $person['name'];
      $temp['id'] = $person['id'];
      $people[] = $temp;
    }
    
    $member_id = $person['id'];
  }
  
  $options = array();
  $person_options = array();
  $entire = array();
  foreach($people as $t){
    foreach($results as $item){
      if($t['id']==$item['id']){
        $options[] = $item['option_id'];
      }
    }
    $person_options['options'] = $options;
    $person_options['name'] = $t['name'];
    $entire[$t['id']] = $person_options;
    
    $options = array();
    $person_options = array();
    
  }
  //echo("<pre>" . print_r($options) . "</pre>");
  
  return $entire;
}

?>