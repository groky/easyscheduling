<?php

define("SMARTY_HOME", "../smarty/");

define("CONFIG_PATH", "./config/");

define("SMARTY_CONFIG_FILE", CONFIG_PATH . "smarty.conf");

//include(SMARTY_HOME . "Config_File.class.php");
include(SMARTY_HOME . "Smarty.class.php");

?>