<?php
  function login($email, $password){
    global $conn;
    $logged_in = false;
    $sql = "select m.first_name, m.last_name, i.organisation_id from member m, organiser i, organisation o where
            m.id = i.member_id and
            o.id = i.organisation_id and 
            o.email='$email' and o.`password` ='". sha1($password) . "';";
    //echo $sql;
    
    $qh = mysql_query($sql, $conn);
    //mysql_error();
    $info = array();
    while($line = mysql_fetch_assoc($qh)){
      $info[] = $line;
    }
    
    //print_r('<pre>' . $info . '</pre>');
    if(count($info)<1){
      $logged_in = false;
    }
    else{
      $logged_in = true;
    }
    $info[] = array("logged_in" => $logged_in);
    
    return $info;
  }
  
?>