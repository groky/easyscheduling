<?php
  
  require_once("login.php");
  
  include('./classes/pear/Mail.php');
  
  define('CONFIG_FILE', "config/pages.ini");
  
  //define('FROM_EMAIL', "easyscheduling.com.au <info@easyscheduling.com.au>");
  define('FROM_EMAIL', "EasyScheduling Team <info@easyscheduling.com.au");
  define('USERNAME', "kgrovers@yahoo.com");
  define('PASSWORD', "sully7552");
  define('PORT', 25);
  define('HOST', "smtp.mail.yahoo.com");
  //define('LINK', "http://localhost/es/?page_name=m_s");
  define('LINK', "http://www.easyscheduling.com.au/?page_name=m_s");
  
  function get_request_var($name, $default = null)
    {
    //    Check if the specified var exists
        if(!array_key_exists($name, $_REQUEST))
        {
            if($default !== null)
                return $default;
            else
                throw new Exception("Missing parameter: {$name}", 100);
        }
 
        else
        {
            $magic_quotes = get_magic_quotes_gpc();
       
            $data = $_REQUEST[$name];
            $result = $default;
 
            if(is_array($data))
            {
                $result = array();
           
                foreach($data as $key => $value)
                {
                    if($magic_quotes != 0) {
                        $value = stripslashes($value);
                        //$value = stripslashes_recursive($value);
                    }
 
                    $result[$key] = $value;
                }
            }
 
            else
            {
                if($magic_quotes != 0) {
                    $data = stripslashes($data);
                    //$data = stripslashes_recursive($data);
                }
 
                $result = $data;
            }
 
            return $result;
        }
    }
  
  function load_ini_file(){
    $ini_array = parse_ini_file(CONFIG_FILE);
    return $ini_array;
  }
  
  function alert($arg){
    print("<script>alert('".$arg."'); </script>");
  }
  
  function check_email($email){
        $qtext = '[^\\x0d\\x22\\x5c\\x80-\\xff]';
        $dtext = '[^\\x0d\\x5b-\\x5d\\x80-\\xff]';
        $atom = '[^\\x00-\\x20\\x22\\x28\\x29\\x2c\\x2e\\x3a-\\x3c'.
        '\\x3e\\x40\\x5b-\\x5d\\x7f-\\xff]+';
        $quoted_pair = '\\x5c[\\x00-\\x7f]';
        $domain_literal = "\\x5b($dtext|$quoted_pair)*\\x5d";
        $quoted_string = "\\x22($qtext|$quoted_pair)*\\x22";
        $domain_ref = $atom;
        $sub_domain = "($domain_ref|$domain_literal)";
        $word = "($atom|$quoted_string)";
        $domain = "$sub_domain(\\x2e$sub_domain)*";
        $local_part = "$word(\\x2e$word)*";
        $addr_spec = "$local_part\\x40$domain";
         
        return preg_match("!^$addr_spec$!", $email) ? 1 : 0;
    }

  /**
    *check the user's credentials and create the necessary reference data
   */
  function do_session_login($email, $password){
    $info = login($email, $password);
    $logged_in;
    if(isset($info[1])){
      if($info[1]["logged_in"]==true){
        create_user_cookie($info);
      }
      $logged_in = $info[1]["logged_in"];
    }
    else{
      $logged_in = $info[0]["logged_in"];
    }
    
    
    return $logged_in;
  }
  /**
    * creates the error messages at the top of the body section
  */
  function error($errorString){
    print("<p class='error'> $errorString</p>");
  }
  
  function create_user_cookie($info){
    $expire = time() + 60 * 60 * 2; //the cookie will expire in 2 hours
    $str_cookie_val = "first_name=" . $info[0]['first_name'] . 
                      "; last_name=" . $info[0]['last_name'] .
                      "; organisation_id=" . $info[0]['organisation_id'];
    //alert($str_cookie_val);
    setcookie("user", $str_cookie_val, $expire);
    
    //alert($_COOKIE['user']);
  }
  
  function get_name_from_cookie(){
    $vals = $_COOKIE['user'];
    $vals = explode(";", $vals);
    
    $val = explode("=",$vals[0]);
    $first_name = $val[1];
    
    $val = explode("=", $vals[1]);
    $last_name = $val[1];
    
    return $first_name . " " . $last_name;
    
  }
  
  function get_org_id(){
    $vals = $_COOKIE['user'];
    $vals = explode(";", $vals);
    
    $val = explode("=", $vals[2]);
    
    return $val[1];
  }
  
  function user_is_logged_in(){
    $logged_in = false;
    //alert("checking...");
    if(isset($_COOKIE['user'])){
      $logged_in = true;
    }
    //alert("checked");
    return $logged_in;
  }
  
  function logout(){
    setcookie("user", "", time()-3600);
    header("Location: ?");
  }
  
  function show_page($page){
    header("Location: ?page_name=$page");
  }

  function get_date($format, $unix_timestamp){
    return date($format, $unix_timestamp);
  }
  
  
  function get_ipx() {
    $length=52;
    $vowels = 'aeiuoAEUOI';
    $consonants = 'bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ1234567890!-$';
   
    $password = '';
    $alt = time() % 2;
    for ($i = 0; $i < $length; $i++) {
      if ($alt == 1) {
        $password .= $consonants[(rand() % strlen($consonants))];
        $alt = 0;
      } else {
        $password .= $vowels[(rand() % strlen($vowels))];
        $alt = 1;
      }
    }
    return $password;
  }

  function sendMail( $link, $email, $event_info){
    
    $subject = "Link for ". $event_info['event_name'];
    
    $body = "Thank you for using easyscheduling.com.au. 
                
    The link you've requested follows.
                
    $link
                
    Kind regards,
    Easyscheduling Team";

    $headers = array ('From' => FROM_EMAIL,
      'To' => $email,
      'Subject' => $subject);
    $smtp = Mail::factory('smtp',
      array ('host' => HOST,
        'auth' => true,
        'username' => USERNAME,
        'password' => PASSWORD,
        'port'=> PORT));

    $mail = $smtp->send($email, $headers, $body);

    if (PEAR::isError($mail)) {
      echo("<p>" . $mail->getMessage() . "</p>");
     } else {
      echo("<p>Message successfully sent!</p>");
     }
  }

?>