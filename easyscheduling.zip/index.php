<?php

include ("./classes/db.php");
include ("./classes/functions.php");
  $errors = "";
  $page_names = load_ini_file();

  $page_name = get_request_var("page_name", false);
  $logout = get_request_var("logout", false);

  if($logout==1){
    logout();
  }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <link rel="Shortcut Icon" href="./images/minilogoblue.jpg">
    <link rel="stylesheet" type="text/css" href="./css/style.css" />
    <link rel="stylesheet" type="text/css" href="./css/calendar.css" />
    <link rel="stylesheet" type="text/css" href="./js/clockpick/clockpick.css" />
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/calendar_eu.js"></script>
    <script src="./js/clockpick/jquery.clockpick.js"></script>
  </head>
  <body>
    <div class="footer">
      <a href="?page_name=c_t">Terms and Conditions</a> &copy; 2009
    </div>
  <div class="login-box">
    <?php 
      if(user_is_logged_in()){
        //alert("winner!");
        include("./webroot/show_login.php");
        //include ("./webroot/menu.php");
      }
      else{
        include("./webroot/not_logged_in.php");
      }
    ?>
  </div>
    <table>
      <tr>
        <td><img class="logo" src="./images/firstdraftbanner.jpg"></img></td>
      </tr>
    </table>

    <?php
         //include ("./webroot/menu.php");
         if($page_name!==false && $page_name!='main'){
          //print_r($page_name);
         } else {
          $page_name='main';
         }   
         //print_r($page_name);
         $page = $page_names[$page_name];
         //print_r($page);
         include($page);
    ?>
  </body>
</html>
