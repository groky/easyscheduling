<?php
  
  $login = get_request_var("login", false);
  $email = get_request_var("email", false);
  $password = get_request_var("password", false);
  
  $validate = true;
  
  if(user_is_logged_in()){
    //do_relocation();
    show_page("l_e");
  }
  else{
  
    if($login!==false){
      
      if(validate($email, $password, $validate)){
        //print("<script>alert('starting it!');</script>"); 
        if(!do_session_login($email, $password)){
          $errors = "* Incorrect email/password combination. Try again...";
          error($errors);
        }
        else{
          show_page("l_e");
        }
      }
      else{
        error($errors);
      }
    }
  }

  function validate($email, $password, $validate){
    global $errors;
    
    if(check_email($email)!=1){
      $errors = $errors . "* A valid email address is required <br />";
      $validate = false;
    }
    if(strlen($password)<1 || $password==""){
      $errors = $errors . "* A password is required";
      $validate = false;
    }
    
    
    return $validate;
  }
?>

<form method="post" action="?" >
<table class="form-table">
  <tr>
    <td>
      <h4>
        Load an existing Profile
      </h4>
    </td>
  </tr>
  <tr>
    <td><label>Email address<label></td>
    <td><input type="text" name="email" value="<?php echo $email; ?>" /></td>
  </tr>
  <tr>
    <td><label>Password</label></td>
    <td><input type="password" name="password" /><td>
  </tr>
   <tr>
      <td></td>
      <td><input type="submit" value="login" name="login" /></td>
    </tr>
    <input type="hidden" name="page_name" value="l_o" />
</table>
</form>
