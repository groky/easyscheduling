
<table>
  <tr>
    <td class="login-font">
      <img src="./images/MiniHouse.jpg" alt="home"></img>[<a href="?">Home</a>]&nbsp; [<a href="?page_name=l_e">Events</a>]&nbsp; You are logged in as 
      <span class="easy"><?php echo(get_name_from_cookie()); ?></span>
      &nbsp; [<a href="?logout=1">logout</a>]
    </td>
  </tr>
</table>