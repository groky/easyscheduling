<?php

?>
    <ul>
      <img src="./images/MiniEmptylogoblue.jpg"></img><span class="steps">Step 1:</span> <span class="easy">Create</span>/load your profile<br/>
      <img src="./images/MiniEmptylogoblue.jpg"></img><span class="steps">Step 2:</span> Schedule an <span class="easy">event</span>/meeting (up to seven <span class="easy">dates</span>/locations)<br/>
      <img src="./images/MiniEmptylogoblue.jpg"></img><span class="steps">Step 3:</span> Invite people<br/>
      <img src="./images/MiniEmptylogoblue.jpg"></img><span class="steps">Step 4:</span> Collect the results and see what's the most convenient date<br/>
    </ul>
    
    <br/>
    What is <b><span class="easy">easy</span>scheduling.com.au</b>?<br>
    <br/><span class="easy">easy</span>scheduling.com.au will help you establish the best <span class="easy">date</span>/location for your next <span class="easy">event</span>/meeting <br />by soliciting responses from your potential invitees.
    <br/>With 4 easy steps to follow, the task of finding the best <span class="easy">date</span>/location is <span class="easy">easy</span> and convenient.
    <br/>Enjoy the simplicity, appreciate the effectiveness.
    <script type="text/javascript" >
      function changeIcon(arg, id){
         //alert("getting ready to change the icon");
         if(arg==1){
          document.getElementById(id).src = "./images/Minilogoblue.jpg";
         }
         else{
          document.getElementById(id).src = "./images/Miniemptylogoblue.jpg";
         }
      }
    </script>        
                 
     <table class="body-table">
      <thead>
        <th>
          <a href="?page_name=c_o" onmouseover="javascript:changeIcon(1, 'icon');" onmouseout="javascript:changeIcon(0, 'icon');">Create a new profile </a><img src="./images/Miniemptylogoblue.jpg" id="icon"></img>
        </th>
        <th><a href="?page_name=l_o" onmouseover="javascript:changeIcon(1, 'icon1');" onmouseout="javascript:changeIcon(0, 'icon1');">Load an existing profile </a><img src="./images/Miniemptylogoblue.jpg" id="icon1"></img>
      </thead>
      <!--<tr>
        <td>
           <li>Schedule an <span class="easy">event</span>/meeting</li>
        </td>
        <td>
           <li>Schedule an <span class="easy">event</span>/meeting</li>
           <li>Edit your profile</li>
           <li>Edit your <span class="easy">event</span>/meeting</li>
           <li>View the results</li>           
         </td>
      </tr>!-->
    </table>