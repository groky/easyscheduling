<?php
  require_once("./classes/events.php");
  
  if(!user_is_logged_in()){
    show_page("l_o");
  }
  
  $events = get_events(get_org_id());
  //print("<pre>" . var_dump($events) . "</pre>");
  //print("<pre>" . var_dump($events) . "</pre>");
  
  if(count($events)<1){
    show_page("c_e");
  }
  else{

?>
    <script type="text/javascript" >
      function changeIcon(arg, id){
         //alert("getting ready to change the icon");
         if(arg==1){
          document.getElementById(id).src = "./images/Minilogoblue.jpg";
         }
         else{
          document.getElementById(id).src = "./images/Miniemptylogoblue.jpg";
         }
      }
    </script>
    
<img src="./images/new_event.jpeg" alt="new event"></img><a href="?page_name=c_e"> Create Event</a>    
    
<table class="body-table">
  <thead>
    <th>Event Name</th>
    <th>Organiser</th>
    <th>Multi-day</th>
  </thead>
  
  <tbody>
    <?php 
    //print("<pre>" . var_dump($events) . "</pre>");
    for($i=0;$i<count($events); $i++) { 
            $event = $events[$i];
            $polls_exist = event_has_poll_results($event['id']);
            //alert($polls_exists);
            //print("<pre>" . var_dump($event) . "</pre>");
    ?>
      <tr class="<?php echo($i%2>0? '': 'alternate'); ?>" onmouseover="javascript:changeIcon(1, 'icon<?php echo($i); ?>');" onmouseout="javascript:changeIcon(0, 'icon<?php echo($i); ?>');">
        <td><img src="./images/MiniEmptylogoblue.jpg" id="icon<?php echo($i); ?>"><?php echo($event["event_name"]); ?></td>
        <td><?php echo($event["contact_person"]); ?></td>
        <td><?php echo($event["multi_day"]==0 ? "no" : "yes"); ?></td>
        <td><a href="?page_name=c_e&id=<?php echo ($event['id']); ?>"><img src="./images/edit.jpeg" alt="edit event" title="Edit <?php echo($event['event_name']); ?>'s event details"></img></a></td>
        <td><a href="?page_name=t_t&id=<?php echo ($event['id']); ?>&multi=<?php echo($event["multi_day"]); ?>"><img src="./images/cal.gif" alt="view timetable" title="Edit Timetable for <?php echo($event['event_name']); ?>"></img></a></td>
        <td><a href="?page_name=e_n&id=<?php echo ($event['id']); ?>&multi=<?php echo($event["multi_day"]); ?>"><img src="./images/email.jpeg" alt="create link" title="Create link to <?php echo($event['event_name']); ?>'s poll page"></img></a></td>
        <?php if($polls_exist){ ?>
        <td><a href="?page_name=r_p&id=<?php echo ($event['id']); ?>&multi=<?php echo($event["multi_day"]); ?>"><img src="./images/result.jpeg" alt="view result" title="See <?php echo($event['event_name']); ?>'s poll result page"></img></a></td>
        <?php } ?>
      </tr>
    <?php } ?>
  </tbody>
  
</table>

<?php } ?>