<table>
  <tr>
    <td class="login-font">
      <img src="./images/MiniHouse.jpg" alt="home"></img>[<a href="?">Home</a>]&nbsp;You are currently <strong>not</strong> logged in.&nbsp;[<a href="?page_name=l_o">Login</a>]
    </td>
  </tr>
</table>
