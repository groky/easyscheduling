<br />
<br />
<p align=justify>
  <font size="2px">
    Thank you. Your choices have been successfully applied.<br />
    Your <span class="easy">event</span>/meeting organiser will be in touch with you soon. <br />
    <br/>
    Regards,<br/>
    EasyScheduling Team
  </font>
</p>