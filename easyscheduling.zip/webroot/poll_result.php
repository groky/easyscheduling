<?php
  include("./classes/profile.php");
  include("./classes/events.php");
  
  $event_id = get_request_var("id", false);
  $multi=get_request_var("multi", false);
  
  if(!user_is_logged_in()){
    show_page("l_o");
  }
  $event = get_event_from_id($event_id);
  $time_table = get_timetable($event_id);
  $choices = get_poll_result_list($event_id);
  
  //$time_table_count = count($time_table);
  
  //echo("<pre>". print_r($time_table) . "</pre><br /><br />");
  //echo("<pre>". print_r($choices) . "</pre>");
?>

<table>
  <th colspan="4">
    Options Provided for <strong><?php echo($event['event_name']); ?></strong>
  </th>
  <?php for($opt=0;$opt<count($time_table);$opt++){ 
    $option = $time_table[$opt];
    if(strlen($option['start'])>0){
  ?>
  <tr class="<?php echo($opt%2>0? '': 'alternate'); ?>">
    <td><img src="./images/minilogoblue.jpg"></img><?php echo($opt + 1); ?></td> 
    <td><?php echo($option['location']); ?></td>
    <td><?php echo($option['start'] . " @ " . $option['start_time']); ?></td>
    <td><?php echo($multi==1?$option['end'] . " @ " . $option['end_time'] : $option['end_time']); ?></td>
  </tr>
  
  <?php }}?>
</table>

<table class="body-table">
  <thead>
  <th>
    The Results
  </th>
  </thead>
  <tr>
    <td><strong>Guest</strong></td>
  <?php for($opt=0;$opt<count($time_table); $opt++){
    $option = $time_table[$opt];
    if(strlen($option['start'])>0){?>
    <td align="center"><strong>Option <?php echo($opt+1); ?></strong> <br /> <!--  <img src="./images/minilogoblue.jpg" ></img> --></td>
  
  <?php }} ?>
  </tr>
  <tr>&nbsp;</tr>
  <tr>&nbsp;</tr>
  <?php  
  foreach($choices as $row){
    $options = $row['options'];
    
  ?>
  <tr rowspan="3" >
    <td> <?php echo($row['name']); ?> </td>
   
  <?php foreach($time_table as $time) { ?>
        <td align="center">
        <?php
          for($o=0;$o<count($options);$o++){
            $option = $options[$o];
            if($time['start']){
              echo($option==$time['option_id'] ? "<img src='./images/minilogoblue.jpg'></img>" : ""); 
            }
          }
        ?>
        </td>  
  <?php } ?>
  </tr>
  <?php } ?>
</table>